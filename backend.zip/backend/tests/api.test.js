const request = require('supertest');
const express = require('express');
const healthRoutes = require('../routes/health');
const marketRoutes = require('../routes/market');
const stockRoutes = require('../routes/stock');

// Mock the stock service
jest.mock('../services/alphaVantage', () => {
  const originalModule = jest.requireActual('../services/alphaVantage');
  return {
    ...originalModule,
    getStockData: jest.fn()
  };
});

const { getStockData } = require('../services/alphaVantage');

const app = express();
app.use(express.json());
app.use('/health', healthRoutes);
app.use('/api/market', marketRoutes);
app.use('/api/stock', stockRoutes);

describe('API Tests', () => {
  beforeEach(() => {
    jest.clearAllMocks();
  });

  describe('GET /health', () => {
    it('should return health status', async () => {
      const res = await request(app)
        .get('/health')
        .expect(200);
      
      expect(res.body).toHaveProperty('ok', true);
      expect(res.body).toHaveProperty('uptime');
      expect(res.body).toHaveProperty('ts');
      expect(typeof res.body.uptime).toBe('number');
    });
  });

  describe('GET /api/market/stocks', () => {
    it('should return an array of stocks', async () => {
      const res = await request(app)
        .get('/api/market/stocks')
        .expect(200);
      
      expect(Array.isArray(res.body)).toBe(true);
      if (res.body.length > 0) {
        expect(res.body[0]).toHaveProperty('symbol');
      }
    });
  });

  describe('GET /api/stock/:symbol', () => {
    describe('When no API key present (mock data)', () => {
      beforeEach(() => {
        // Mock getStockData to return mock data
        getStockData.mockResolvedValue({
          symbol: 'AAPL',
          currentPrice: 178.72,
          riskLevel: 'MEDIUM RISK',
          recommendation: 'BUY',
          historicalPrices: [
            { date: '2024-10-18', price: 175.50 }
          ],
          predictedPrices: [
            { date: '2024-12-02', price: 180.00 }
          ],
          fundamentals: 'Test fundamentals',
          riskAssessment: 'Test risk assessment',
          investmentRecommendation: 'Test recommendation',
          keyFactors: ['Factor 1', 'Factor 2']
        });
      });

      it('should return mock data with correct schema', async () => {
        const res = await request(app)
          .get('/api/stock/AAPL')
          .expect(200);
        
        expect(res.body).toHaveProperty('symbol');
        expect(res.body).toHaveProperty('currentPrice');
        expect(res.body).toHaveProperty('riskLevel');
        expect(res.body).toHaveProperty('recommendation');
        expect(res.body).toHaveProperty('historicalPrices');
        expect(res.body).toHaveProperty('predictedPrices');
        expect(res.body).toHaveProperty('fundamentals');
        expect(res.body).toHaveProperty('riskAssessment');
        expect(res.body).toHaveProperty('investmentRecommendation');
        expect(res.body).toHaveProperty('keyFactors');
        
        expect(Array.isArray(res.body.historicalPrices)).toBe(true);
        expect(Array.isArray(res.body.predictedPrices)).toBe(true);
        expect(Array.isArray(res.body.keyFactors)).toBe(true);
        
        if (res.body.historicalPrices.length > 0) {
          expect(res.body.historicalPrices[0]).toHaveProperty('date');
          expect(res.body.historicalPrices[0]).toHaveProperty('price');
        }
      });

      it('should sanitize and uppercase symbol', async () => {
        const res = await request(app)
          .get('/api/stock/aapl')
          .expect(200);
        
        expect(getStockData).toHaveBeenCalledWith('AAPL');
        expect(res.body.symbol).toBe('AAPL');
      });
    });

    describe('When API key present and rate limit not exceeded', () => {
      beforeEach(() => {
        // Mock successful Alpha Vantage response
        getStockData.mockImplementation(async (symbol) => {
          const transformed = {
            symbol: symbol.toUpperCase(),
            currentPrice: 178.72,
            riskLevel: 'MEDIUM RISK',
            recommendation: 'BUY',
            historicalPrices: [
              { date: '2024-11-01', price: 178.72 },
              { date: '2024-11-02', price: 179.50 }
            ],
            predictedPrices: [
              { date: '2024-12-02', price: 180.00 }
            ],
            fundamentals: 'Test',
            riskAssessment: 'Test',
            investmentRecommendation: 'Test',
            keyFactors: ['Factor 1']
          };
          
          return transformed;
        });
      });

      it('should call Alpha Vantage and return transformed data', async () => {
        const res = await request(app)
          .get('/api/stock/AAPL')
          .expect(200);
        
        expect(getStockData).toHaveBeenCalledWith('AAPL');
        expect(res.body).toHaveProperty('symbol', 'AAPL');
        expect(res.body).toHaveProperty('currentPrice');
        expect(res.body).toHaveProperty('historicalPrices');
      });
    });

    describe('When rate limit exceeded', () => {
      beforeEach(() => {
        // Mock rate limit exceeded
        getStockData.mockImplementation(async (symbol) => {
          const error = new Error('Rate limit exceeded. Please wait 30 seconds.');
          error.statusCode = 429;
          throw error;
        });
      });

      it('should return HTTP 429 when rate limit exceeded', async () => {
        const res = await request(app)
          .get('/api/stock/AAPL')
          .expect(429);
        
        expect(res.body).toHaveProperty('error');
        expect(res.body.error).toContain('Rate limit exceeded');
      });
    });

    describe('Input validation', () => {
      it('should handle special characters in symbol', async () => {
        getStockData.mockResolvedValue({
          symbol: 'TEST',
          currentPrice: 100,
          riskLevel: 'MEDIUM RISK',
          recommendation: 'BUY',
          historicalPrices: [],
          predictedPrices: [],
          fundamentals: 'Test',
          riskAssessment: 'Test',
          investmentRecommendation: 'Test',
          keyFactors: []
        });

        const res = await request(app)
          .get('/api/stock/TEST123')
          .expect(200);
        
        expect(res.body.symbol).toBe('TEST');
      });
    });
  });
});

