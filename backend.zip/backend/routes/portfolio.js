const express = require('express');
const router = express.Router();
const { nanoid } = require('nanoid');
const {
  getCollection,
  addToCollection,
  updateInCollection,
  deleteFromCollection
} = require('../lib/db');
const { getStockData } = require('../services/alphaVantage');

/**
 * Get portfolio summary
 */
router.get('/', async (req, res, next) => {
  try {
    const userId = req.headers['user-id'] || '1';
    const holdings = await getCollection('portfolio_holdings');
    const userHoldings = holdings.filter(h => h.userId === userId);

    let totalValue = 0;
    for (const holding of userHoldings) {
      try {
        const stockData = await getStockData(holding.symbol);
        totalValue += stockData.currentPrice * holding.shares;
      } catch (error) {
        // Use purchase price if stock data unavailable
        totalValue += holding.pricePerShare * holding.shares;
      }
    }

    const paperBalance = 10000; // Default paper balance

    res.json({
      totalValue: parseFloat(totalValue.toFixed(2)),
      paperBalance: parseFloat(paperBalance.toFixed(2)),
      holdingsCount: userHoldings.length
    });
  } catch (error) {
    next(error);
  }
});

/**
 * Get all holdings
 */
router.get('/holdings', async (req, res, next) => {
  try {
    const userId = req.headers['user-id'] || '1';
    const holdings = await getCollection('portfolio_holdings');
    const userHoldings = holdings.filter(h => h.userId === userId);
    res.json(userHoldings);
  } catch (error) {
    next(error);
  }
});

/**
 * Create a new holding
 */
router.post('/holdings', async (req, res, next) => {
  try {
    const { symbol, companyName, shares, pricePerShare, purchaseDate } = req.body;

    if (!symbol || !shares || !pricePerShare) {
      return res.status(400).json({
        error: 'Missing required fields: symbol, shares, pricePerShare'
      });
    }

    const userId = req.headers['user-id'] || '1';
    const holding = {
      id: nanoid(),
      userId,
      symbol: symbol.toUpperCase(),
      companyName: companyName || symbol,
      shares: parseFloat(shares),
      pricePerShare: parseFloat(pricePerShare),
      purchaseDate: purchaseDate || new Date().toISOString().split('T')[0],
      createdAt: new Date().toISOString()
    };

    const created = await addToCollection('portfolio_holdings', holding);

    // Create transaction record
    const transaction = {
      id: nanoid(),
      userId,
      type: 'BUY',
      symbol: holding.symbol,
      shares: holding.shares,
      pricePerShare: holding.pricePerShare,
      totalAmount: holding.shares * holding.pricePerShare,
      date: holding.purchaseDate,
      createdAt: new Date().toISOString()
    };
    await addToCollection('transactions', transaction);

    res.status(201).json(created);
  } catch (error) {
    next(error);
  }
});

/**
 * Delete a holding
 */
router.delete('/holdings/:id', async (req, res, next) => {
  try {
    const { id } = req.params;
    await deleteFromCollection('portfolio_holdings', id);
    res.status(204).send();
  } catch (error) {
    if (error.message.includes('not found')) {
      return res.status(404).json({ error: error.message });
    }
    next(error);
  }
});

/**
 * Get transaction history
 */
router.get('/transactions', async (req, res, next) => {
  try {
    const userId = req.headers['user-id'] || '1';
    const transactions = await getCollection('transactions');
    const userTransactions = transactions
      .filter(t => t.userId === userId)
      .sort((a, b) => new Date(b.date) - new Date(a.date));
    res.json(userTransactions);
  } catch (error) {
    next(error);
  }
});

module.exports = router;

