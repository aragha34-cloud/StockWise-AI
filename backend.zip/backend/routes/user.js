const express = require('express');
const router = express.Router();
const { getCollection, updateInCollection, addToCollection } = require('../lib/db');

/**
 * Get user profile
 */
router.get('/', async (req, res, next) => {
  try {
    const userId = req.headers['user-id'] || '1';
    const users = await getCollection('users');
    let user = users.find(u => u.id === userId);

    if (!user) {
      // Create default user
      user = {
        id: userId,
        name: 'Nidhi Konanur',
        email: 'nidhikonantbsg@gmail.com',
        level: 'BEGINNER INVESTOR',
        experienceLevel: 'Beginner',
        riskTolerance: 'Moderate',
        createdAt: new Date().toISOString()
      };
      await addToCollection('users', user);
    }

    res.json(user);
  } catch (error) {
    next(error);
  }
});

/**
 * Update user profile
 */
router.put('/', async (req, res, next) => {
  try {
    const userId = req.headers['user-id'] || '1';
    const updates = req.body;

    const users = await getCollection('users');
    let user = users.find(u => u.id === userId);

    if (!user) {
      // Create user if doesn't exist
      user = {
        id: userId,
        ...updates,
        createdAt: new Date().toISOString()
      };
      await addToCollection('users', user);
      return res.status(201).json(user);
    }

    const updated = await updateInCollection('users', userId, {
      ...updates,
      updatedAt: new Date().toISOString()
    });

    res.json(updated);
  } catch (error) {
    next(error);
  }
});

module.exports = router;

