const express = require('express');
const router = express.Router();
const { getCollection } = require('../lib/db');

/**
 * Get market stocks list
 */
router.get('/stocks', async (req, res, next) => {
  try {
    const marketStocks = await getCollection('market_stocks');
    
    // If empty, return default stocks
    if (marketStocks.length === 0) {
      const defaultStocks = [
        { symbol: 'AAPL', name: 'Apple Inc.', price: 178.72, change: 1.39, positive: true },
        { symbol: 'MSFT', name: 'Microsoft', price: 374.23, change: -0.33, positive: false },
        { symbol: 'GOOGL', name: 'Alphabet', price: 139.67, change: 2.35, positive: true },
        { symbol: 'AMZN', name: 'Amazon', price: 145.33, change: 1.3, positive: true },
        { symbol: 'NVDA', name: 'NVIDIA', price: 495.22, change: 2.56, positive: true },
        { symbol: 'TSLA', name: 'Tesla', price: 248.5, change: -1.63, positive: false },
        { symbol: 'META', name: 'Meta Platforms', price: 355.2, change: 1.62, positive: true },
        { symbol: 'JPM', name: 'JPMorgan Chase', price: 156.89, change: 0.63, positive: true }
      ];
      return res.json(defaultStocks);
    }

    res.json(marketStocks);
  } catch (error) {
    next(error);
  }
});

module.exports = router;

