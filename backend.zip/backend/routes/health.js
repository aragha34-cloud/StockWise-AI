const express = require('express');
const router = express.Router();

const startTime = Date.now();

router.get('/', (req, res) => {
  const uptime = Math.floor((Date.now() - startTime) / 1000);
  res.json({
    ok: true,
    uptime,
    ts: new Date().toISOString()
  });
});

module.exports = router;

