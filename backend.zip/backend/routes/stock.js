const express = require('express');
const router = express.Router();
const { getStockData } = require('../services/alphaVantage');

router.get('/:symbol', async (req, res, next) => {
  try {
    const { symbol } = req.params;
    
    // Validate and sanitize symbol
    if (!symbol || typeof symbol !== 'string' || symbol.trim().length === 0) {
      return res.status(400).json({
        error: 'Invalid symbol parameter. Symbol is required and must be a non-empty string.'
      });
    }

    const sanitizedSymbol = symbol.toUpperCase().trim();
    
    try {
      const stockData = await getStockData(sanitizedSymbol);
      res.json(stockData);
    } catch (error) {
      // Handle rate limit errors
      if (error.statusCode === 429) {
        return res.status(429).json({
          error: error.message
        });
      }
      throw error;
    }
  } catch (error) {
    next(error);
  }
});

module.exports = router;

