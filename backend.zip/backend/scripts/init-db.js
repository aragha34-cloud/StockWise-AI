require('dotenv').config();
const { writeDB } = require('../lib/db');

async function initDB() {
  const defaultData = {
    users: [
      {
        id: '1',
        name: 'Nidhi Konanur',
        email: 'nidhikonantbsg@gmail.com',
        level: 'BEGINNER INVESTOR',
        experienceLevel: 'Beginner',
        riskTolerance: 'Moderate',
        createdAt: new Date().toISOString()
      }
    ],
    portfolio_holdings: [
      {
        id: '1',
        userId: '1',
        symbol: 'AAPL',
        companyName: 'Apple Inc.',
        shares: 10,
        pricePerShare: 150.00,
        purchaseDate: '2025-10-27',
        createdAt: new Date().toISOString()
      }
    ],
    transactions: [
      {
        id: '1',
        userId: '1',
        type: 'BUY',
        symbol: 'AAPL',
        shares: 10,
        pricePerShare: 150.00,
        totalAmount: 1500.00,
        date: '2025-10-27',
        createdAt: new Date().toISOString()
      }
    ],
    stock_cache: {},
    market_stocks: [
      { symbol: 'AAPL', name: 'Apple Inc.', price: 178.72, change: 1.39, positive: true },
      { symbol: 'MSFT', name: 'Microsoft', price: 374.23, change: -0.33, positive: false },
      { symbol: 'GOOGL', name: 'Alphabet', price: 139.67, change: 2.35, positive: true },
      { symbol: 'AMZN', name: 'Amazon', price: 145.33, change: 1.3, positive: true },
      { symbol: 'NVDA', name: 'NVIDIA', price: 495.22, change: 2.56, positive: true },
      { symbol: 'TSLA', name: 'Tesla', price: 248.5, change: -1.63, positive: false },
      { symbol: 'META', name: 'Meta Platforms', price: 355.2, change: 1.62, positive: true },
      { symbol: 'JPM', name: 'JPMorgan Chase', price: 156.89, change: 0.63, positive: true }
    ]
  };

  try {
    await writeDB(defaultData);
    console.log('✅ Database initialized successfully at', process.env.DATA_FILE || './data/stockwise.json');
  } catch (error) {
    console.error('❌ Error initializing database:', error);
    process.exit(1);
  }
}

initDB();

