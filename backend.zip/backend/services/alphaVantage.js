const fetch = require('node-fetch');
const rateLimiter = require('../lib/rateLimiter');
const { getStockCache, setStockCache } = require('../lib/db');

const API_KEY = process.env.ALPHA_VANTAGE_API_KEY;
const CACHE_TTL_MS = 60 * 60 * 1000; // 1 hour

/**
 * Check if cache entry is still valid
 */
function isCacheValid(cacheEntry) {
  if (!cacheEntry || !cacheEntry.cachedAt) return false;
  const cachedAt = new Date(cacheEntry.cachedAt);
  const now = new Date();
  return (now - cachedAt) < CACHE_TTL_MS;
}

/**
 * Fetch stock data from Alpha Vantage
 */
async function fetchStockData(symbol) {
  if (!API_KEY) {
    throw new Error('Alpha Vantage API key not configured');
  }

  if (!rateLimiter.canCall()) {
    const waitTime = rateLimiter.getTimeUntilNextCall();
    throw new Error(`Rate limit exceeded. Please wait ${Math.ceil(waitTime / 1000)} seconds.`);
  }

  const url = `https://www.alphavantage.co/query?function=TIME_SERIES_DAILY_ADJUSTED&symbol=${symbol}&apikey=${API_KEY}`;
  
  try {
    const response = await fetch(url);
    const data = await response.json();
    
    if (data['Error Message']) {
      throw new Error(data['Error Message']);
    }
    
    if (data['Note']) {
      throw new Error('API call frequency limit exceeded');
    }
    
    return data;
  } catch (error) {
    throw new Error(`Failed to fetch from Alpha Vantage: ${error.message}`);
  }
}

/**
 * Transform Alpha Vantage data to our format
 * Extracts last 45 market days of historical data
 */
function transformAlphaVantageData(avData, symbol) {
  const timeSeries = avData['Time Series (Daily Adjusted)'];
  if (!timeSeries) {
    throw new Error('No time series data available');
  }

  // Get all dates and sort (oldest first)
  const dates = Object.keys(timeSeries).sort();
  
  // Get last 45 entries (last 45 market days)
  const last45Dates = dates.slice(-45);
  
  if (last45Dates.length === 0) {
    throw new Error('Insufficient historical data');
  }

  // Most recent date is the last one
  const latestDate = last45Dates[last45Dates.length - 1];
  const latest = timeSeries[latestDate];
  const currentPrice = parseFloat(latest['4. close']);

  // Build historical prices array (last 45 market days)
  const historicalPrices = last45Dates.map(date => ({
    date,
    price: parseFloat(timeSeries[date]['4. close'])
  }));

  // Generate predicted prices (mock forecast)
  const predictedPrices = generatePredictedPrices(currentPrice, latestDate);

  // Get company name
  const companyName = getCompanyName(symbol);

  return {
    symbol: symbol.toUpperCase(),
    currentPrice: parseFloat(currentPrice.toFixed(2)),
    riskLevel: 'MEDIUM RISK',
    recommendation: 'BUY',
    historicalPrices,
    predictedPrices,
    fundamentals: `${companyName} is a leading technology company known for its innovative products and services. It has a strong financial position, with significant cash reserves and a history of consistent revenue growth. The company's diverse product lineup contributes to its robust market presence.`,
    riskAssessment: `${companyName} operates in the highly competitive technology sector, which can lead to market volatility. However, its strong brand, diverse product portfolio, and substantial cash reserves help mitigate some of these risks.`,
    investmentRecommendation: `Analyst consensus rates ${symbol} as a 'Buy,' with an average 12-month price target of $${(currentPrice * 1.03).toFixed(2)}, indicating potential upside from the current price.`,
    keyFactors: [
      'Product innovation',
      'Market competition',
      'Supply chain dynamics',
      'Regulatory environment',
      'Global economic conditions'
    ]
  };
}

/**
 * Generate predicted prices (mock forecast)
 */
function generatePredictedPrices(startPrice, startDate) {
  const prices = [];
  const start = new Date(startDate);
  let currentPrice = startPrice * 1.02; // Slight upward trend

  for (let i = 1; i <= 30; i++) {
    const date = new Date(start);
    date.setDate(date.getDate() + i);
    // Skip weekends (simple check)
    if (date.getDay() === 0) date.setDate(date.getDate() + 1);
    if (date.getDay() === 6) date.setDate(date.getDate() + 1);
    
    // Small random variation
    currentPrice += (Math.random() - 0.5) * 2;
    prices.push({
      date: date.toISOString().split('T')[0],
      price: parseFloat(currentPrice.toFixed(2))
    });
  }

  return prices;
}

/**
 * Get company name from symbol
 */
function getCompanyName(symbol) {
  const companies = {
    AAPL: 'Apple Inc.',
    MSFT: 'Microsoft',
    GOOGL: 'Alphabet',
    AMZN: 'Amazon',
    NVDA: 'NVIDIA',
    TSLA: 'Tesla',
    META: 'Meta Platforms',
    JPM: 'JPMorgan Chase'
  };
  return companies[symbol.toUpperCase()] || symbol;
}

/**
 * Get stock data with caching and rate limiting
 */
async function getStockData(symbol) {
  // Sanitize and validate symbol
  const sanitizedSymbol = symbol.toUpperCase().trim();
  if (!sanitizedSymbol || sanitizedSymbol.length === 0) {
    throw new Error('Invalid symbol parameter');
  }

  // Check cache first
  const cached = await getStockCache(sanitizedSymbol);
  if (isCacheValid(cached)) {
    return cached.data;
  }

  // If no API key, return mock data
  if (!API_KEY) {
    return generateMockStockData(sanitizedSymbol);
  }

  try {
    // Check rate limit before making call
    if (!rateLimiter.canCall()) {
      // Rate limit exceeded - try to return cached data even if expired
      if (cached) {
        console.warn(`Rate limit exceeded, returning expired cache for ${sanitizedSymbol}`);
        return cached.data;
      }
      // No cache available - return 429 error
      const waitTime = rateLimiter.getTimeUntilNextCall();
      const error = new Error(`Rate limit exceeded. Please wait ${Math.ceil(waitTime / 1000)} seconds.`);
      error.statusCode = 429;
      throw error;
    }

    // Fetch from Alpha Vantage
    const avData = await fetchStockData(sanitizedSymbol);
    const transformed = transformAlphaVantageData(avData, sanitizedSymbol);
    
    // Cache the result
    await setStockCache(sanitizedSymbol, { data: transformed });
    
    return transformed;
  } catch (error) {
    // If rate limited (429), re-throw
    if (error.statusCode === 429) {
      throw error;
    }

    // If Alpha Vantage error, try to return cached data even if expired
    if (cached) {
      console.warn(`Using expired cache for ${sanitizedSymbol} due to error:`, error.message);
      return cached.data;
    }
    
    // Fallback to mock data
    console.warn(`Falling back to mock data for ${sanitizedSymbol}:`, error.message);
    return generateMockStockData(sanitizedSymbol);
  }
}

/**
 * Generate mock stock data matching frontend structure
 */
function generateMockStockData(symbol) {
  const companyName = getCompanyName(symbol);
  const basePrice = 200 + Math.random() * 100;
  
  // Generate last 45 days of historical data
  const historicalPrices = [];
  const today = new Date();
  let currentPrice = basePrice * 0.9;
  let daysBack = 45;
  let marketDays = 0;

  while (marketDays < 45) {
    const date = new Date(today);
    date.setDate(date.getDate() - daysBack);
    
    // Skip weekends
    if (date.getDay() !== 0 && date.getDay() !== 6) {
      currentPrice += (Math.random() - 0.4) * 3;
      historicalPrices.push({
        date: date.toISOString().split('T')[0],
        price: parseFloat(currentPrice.toFixed(2))
      });
      marketDays++;
    }
    daysBack--;
  }

  // Sort by date
  historicalPrices.sort((a, b) => new Date(a.date) - new Date(b.date));

  // Generate predicted prices
  const predictedStartDate = new Date(today);
  predictedStartDate.setDate(predictedStartDate.getDate() + 1);
  const predictedPrices = [];
  let predictedPrice = currentPrice * 1.02;
  let predictedDays = 0;

  while (predictedDays < 30) {
    const date = new Date(predictedStartDate);
    date.setDate(date.getDate() + predictedDays);
    
    // Skip weekends
    if (date.getDay() !== 0 && date.getDay() !== 6) {
      predictedPrice += (Math.random() - 0.5) * 2;
      predictedPrices.push({
        date: date.toISOString().split('T')[0],
        price: parseFloat(predictedPrice.toFixed(2))
      });
      predictedDays++;
    }
    predictedDays++;
  }

  return {
    symbol: symbol.toUpperCase(),
    currentPrice: parseFloat(currentPrice.toFixed(2)),
    riskLevel: 'MEDIUM RISK',
    recommendation: 'BUY',
    historicalPrices,
    predictedPrices,
    fundamentals: `${companyName} is a leading technology company known for its innovative products and services. It has a strong financial position, with significant cash reserves and a history of consistent revenue growth. The company's diverse product lineup contributes to its robust market presence.`,
    riskAssessment: `${companyName} operates in the highly competitive technology sector, which can lead to market volatility. However, its strong brand, diverse product portfolio, and substantial cash reserves help mitigate some of these risks.`,
    investmentRecommendation: `Analyst consensus rates ${symbol} as a 'Buy,' with an average 12-month price target of $${(currentPrice * 1.03).toFixed(2)}, indicating potential upside from the current price.`,
    keyFactors: [
      'Product innovation',
      'Market competition',
      'Supply chain dynamics',
      'Regulatory environment',
      'Global economic conditions'
    ]
  };
}

module.exports = {
  getStockData,
  generateMockStockData
};

